#!/bin/bash

java -jar ../spring-cloud-function-compiler/target/spring-cloud-function-compiler-2.0.0.BUILD-SNAPSHOT.jar
